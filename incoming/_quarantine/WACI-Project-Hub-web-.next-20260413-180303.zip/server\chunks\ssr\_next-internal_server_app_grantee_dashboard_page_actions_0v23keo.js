module.exports=[96213,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_grantee_dashboard_page_actions_0v23keo.js.map