var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/ai/generate-project/route.js")
R.c("server/chunks/[externals]_next_dist_0sqmaqd._.js")
R.c("server/chunks/[root-of-the-server]__0p3fo6l._.js")
R.c("server/chunks/node_modules_next_0otr-h1._.js")
R.c("server/chunks/_next-internal_server_app_api_ai_generate-project_route_actions_13keo1p.js")
R.m(62656)
module.exports=R.m(62656).exports
