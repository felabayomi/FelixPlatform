module.exports=[30991,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_grantee_report_page_actions_0pibxpy.js.map