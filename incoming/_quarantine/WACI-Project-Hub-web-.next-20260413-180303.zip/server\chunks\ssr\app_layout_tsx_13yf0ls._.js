module.exports=[33290,a=>{"use strict";var b=a.i(7997);a.s(["default",0,function({children:a}){return(0,b.jsx)("html",{lang:"en",children:(0,b.jsx)("body",{children:a})})},"metadata",0,{title:"WACI Project Hub",description:"Fund real conservation work. One project. One grantee. Measurable impact."}])},70864,a=>{a.n(a.i(33290))}];

//# sourceMappingURL=app_layout_tsx_13yf0ls._.js.map