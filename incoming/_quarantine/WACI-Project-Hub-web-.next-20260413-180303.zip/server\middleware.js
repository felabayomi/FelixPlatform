var R=require("./chunks/[turbopack]_runtime.js")("server/middleware.js")
R.c("server/chunks/[externals]__06rrr22._.js")
R.c("server/chunks/[root-of-the-server]__0rvcm_r._.js")
R.m(62395)
module.exports=R.m(62395).exports
