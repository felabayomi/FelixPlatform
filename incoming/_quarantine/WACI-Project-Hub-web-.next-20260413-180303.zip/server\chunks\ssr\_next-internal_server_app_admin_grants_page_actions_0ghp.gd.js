module.exports=[6265,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_grants_page_actions_0ghp.gd.js.map