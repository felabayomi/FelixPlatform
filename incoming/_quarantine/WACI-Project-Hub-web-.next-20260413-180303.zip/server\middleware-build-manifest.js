globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/5fLVNfHeH2HfTKauoBdWM/_buildManifest.js",
    "static/5fLVNfHeH2HfTKauoBdWM/_ssgManifest.js",
    "static/5fLVNfHeH2HfTKauoBdWM/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/07nlt25rqsgz6.js",
    "static/chunks/0pqt~8bl3ukh4.js",
    "static/chunks/0jg_-2k9dz~4k.js",
    "static/chunks/0257pdz1-imal.js",
    "static/chunks/turbopack-0-~v7dj._oyja.js"
  ]
};
