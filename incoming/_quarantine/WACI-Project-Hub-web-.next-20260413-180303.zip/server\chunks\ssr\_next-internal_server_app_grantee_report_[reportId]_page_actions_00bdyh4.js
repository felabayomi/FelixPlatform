module.exports=[65696,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_grantee_report_%5BreportId%5D_page_actions_00bdyh4.js.map