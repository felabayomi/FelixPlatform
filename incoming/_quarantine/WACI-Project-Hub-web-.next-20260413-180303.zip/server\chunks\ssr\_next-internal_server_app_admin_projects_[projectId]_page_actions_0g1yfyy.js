module.exports=[20225,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_projects_%5BprojectId%5D_page_actions_0g1yfyy.js.map