module.exports=[21772,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_volunteer_reports_new_page_actions_0iu1fxv.js.map