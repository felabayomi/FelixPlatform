module.exports=[10240,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_projects_create_page_actions_02a2-od.js.map