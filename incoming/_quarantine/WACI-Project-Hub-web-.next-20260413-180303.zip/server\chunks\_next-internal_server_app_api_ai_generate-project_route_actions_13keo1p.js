module.exports=[97135,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_ai_generate-project_route_actions_13keo1p.js.map