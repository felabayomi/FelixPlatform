module.exports=[90198,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_volunteer_grant_%5BofferId%5D_page_actions_04t6pcu.js.map