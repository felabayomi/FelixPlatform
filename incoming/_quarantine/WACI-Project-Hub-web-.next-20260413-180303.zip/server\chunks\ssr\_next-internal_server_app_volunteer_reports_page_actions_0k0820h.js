module.exports=[26339,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_volunteer_reports_page_actions_0k0820h.js.map