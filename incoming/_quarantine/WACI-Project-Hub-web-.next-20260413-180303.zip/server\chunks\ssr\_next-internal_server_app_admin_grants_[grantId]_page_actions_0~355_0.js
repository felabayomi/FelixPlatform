module.exports=[28351,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_grants_%5BgrantId%5D_page_actions_0~355_0.js.map